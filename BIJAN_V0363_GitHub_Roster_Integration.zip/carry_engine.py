"""BIJAN Week 11 2026 research-only simulation bridge, v0.3.5.8.

NOT the unchanged V0.3.4 full game model. Reuses historical two-stage RB-lead
method of V0.3.5.1, with fresh 2026 pre-week-11 player observations and
provisional V0.3.5.5 roster IDs. Never makes betting-ready claims.
"""
from __future__ import annotations
import os, json, hashlib, io, zipfile, argparse, datetime, pathlib, warnings
import numpy as np
import pandas as pd
from scipy.special import gammaln, betaln
from scipy.optimize import minimize_scalar
from sklearn.linear_model import LogisticRegression, Ridge

VERSION='BIJAN_V0358_RESEARCH_BRIDGE'
SEASON=2026
WEEK=11
N_DRAWS=20000
SEED=2026112211
FEATURES=['prior_share','p4rushes','p4lead','p4pass_rate']


def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def utcnow():return datetime.datetime.now(datetime.timezone.utc)
def iso(t):return t.isoformat().replace('+00:00','Z')
def read_snapshot(path):
    raw=pathlib.Path(path).read_bytes()
    return pd.read_csv(io.BytesIO(raw),dtype={'player_id':str}),sha_bytes(raw)

def prep_stats(df, season=SEASON, week=WEEK):
    df=df.copy()
    if 'team' not in df.columns and 'recent_team' in df.columns:df=df.rename(columns={'recent_team':'team'})
    for name, opts in {'player_id':['player_id','gsis_id'], 'player_name':['player_name','player_display_name'],
       'team':['team','recent_team'], 'position':['position','pos'],
       'week':['week'], 'season':['season'], 'carries':['carries','rushing_attempts']}.items():
        if name not in df.columns:
            for option in opts:
                if option in df.columns:df[name]=df[option];break
        if name not in df.columns:raise ValueError('Missing required nflverse weekly player stat column '+name+'; columns='+repr(list(df.columns)))
    if 'attempts' not in df.columns:df['attempts']=0
    if 'opponent_team' not in df.columns:raise ValueError('Missing opponent_team from player stats')
    df['week']=pd.to_numeric(df.week,errors='coerce')
    df['season']=pd.to_numeric(df.season,errors='coerce')
    df=df[df.season.eq(season)&df.week.lt(week)&df.week.ge(1)].copy()
    if 'season_type' in df.columns:df=df[df.season_type.astype(str).str.upper().eq('REG')].copy()
    if df.empty:raise ValueError('No 2026 pre-Week-11 regular-season weekly data; refusing to guess.')
    df['team']=df.team.fillna('').astype(str).str.upper().replace({'LA':'LAR','JAC':'JAX','OAK':'LV','SD':'LAC','STL':'LAR'})
    df['opponent_team']=df.opponent_team.fillna('').astype(str).str.upper().replace({'LA':'LAR','JAC':'JAX','OAK':'LV','SD':'LAC','STL':'LAR'})
    df['player_id']=df.player_id.astype(str)
    df['carries']=pd.to_numeric(df.carries,errors='coerce').fillna(0).clip(lower=0)
    df['attempts']=pd.to_numeric(df.attempts,errors='coerce').fillna(0).clip(lower=0)
    # Aggregate possible duplicate feed rows before team totals; reject obvious invalid data.
    df=df.groupby(['season','week','team','opponent_team','player_id'],as_index=False).agg(
        carries=('carries','sum'),attempts=('attempts','sum'),player_name=('player_name','first'),position=('position','first'))
    return df


def fit_v0351_historical(H):
    H=H[(H.season>=2022)&(H.season<=2025)&H.lead_share.notna()&H.prior4_rushes.notna()&(H.rushes>0)].copy()
    H['prior_share']=H.lead_share.clip(.01,.95)
    H['p4rushes']=H.prior4_rushes.clip(1,70)
    H['p4lead']=H.lead_prior4_carries.fillna(H.prior_share*H.p4rushes).clip(0,70)
    med=float(H.prior4_pass_rate.dropna().median())
    H['p4pass_rate']=H.prior4_pass_rate.fillna(med)
    X=H[FEATURES].to_numpy(float)
    iszero=(H.lead_current_carries<=0).to_numpy(int)
    if len(np.unique(iszero))<2:raise ValueError('Historical sample lacks lead zero event variety')
    zero=LogisticRegression(C=.3,max_iter=1200).fit(X,iszero)
    pos=(iszero==0)
    share=H.lead_current_carries/H.rushes
    posfit=Ridge(alpha=1.).fit(X[pos],share.to_numpy()[pos])
    m=np.clip(posfit.predict(X[pos]),.01,.98)
    n=H.rushes.to_numpy(dtype=int)[pos]
    y=H.lead_current_carries.to_numpy(dtype=int)[pos]
    def objective(logk):
        k=np.exp(logk); a=np.maximum(m*k,.001); b=np.maximum((1-m)*k,.001)
        return -float(np.sum(gammaln(n+1)-gammaln(y+1)-gammaln(n-y+1)+betaln(y+a,n-y+b)-betaln(a,b)))
    opt=minimize_scalar(objective,bounds=(np.log(.3),np.log(150)),method='bounded')
    if not opt.success:raise ValueError('Historical beta-binomial dispersion fit did not converge')
    return {'zero':zero,'positive':posfit,'kappa':float(np.exp(opt.x)),'p4pass_median':med,'train_rows':len(H)}


def team_recent(df,team,lookback=4):
    x=df[df.team.eq(team)].copy()
    weeks=sorted(x.week.unique())[-lookback:]
    x=x[x.week.isin(weeks)]
    t=x.groupby('week',as_index=False).agg(carries=('carries','sum'),attempts=('attempts','sum'))
    if len(t)<3:raise ValueError(f'Team {team} has only {len(t)} pregame weeks; refusing extrapolation')
    return x,t, weeks

def build_features(df,schedule,rosters,overrides=None):
    sched=schedule.copy(); players=[];teams=[];flags=[]
    # Opponent allowed from prior weeks, strictly prior to current Sunday.
    opp_allowed=df.groupby(['opponent_team','week'],as_index=False).agg(carries_allowed=('carries','sum'))
    for game in sched.itertuples(index=False):
        for team,opp in [(game.away,game.home),(game.home,game.away)]:
            season_rows, team_weeks, weeks=team_recent(df,team)
            vol=float(team_weeks.carries.tail(4).mean())
            thisopp=opp_allowed[opp_allowed.opponent_team.eq(opp)].sort_values('week').tail(4)
            opp_allow=float(thisopp.carries_allowed.mean()) if len(thisopp)>=3 else vol
            # Modest opponent adjustment; not a calibrated opponent/pace model.
            mu=float(np.clip(.75*vol+.25*opp_allow,10,48))
            avgpass=float(team_weeks.attempts.mean())
            passrate=float(avgpass/(avgpass+vol)) if avgpass+vol else .60
            cands=rosters[(rosters.game_id==game.game_id)&(rosters.team==team)&
                          (rosters.position.isin(['RB','QB','FB','WR','TE']))&rosters.is_53man_candidate.eq(True)].copy()
            cands=cands.drop_duplicates('player_id')
            if cands.empty or not (cands.position=='RB').any():raise ValueError(f'No provisional RB candidates for {game.game_id}/{team}')
            if len(cands[cands.position=='QB'])<2:flags.append({'game_id':game.game_id,'team':team,'issue':'FEWER_THAN_TWO_PROVISIONAL_QBS'})
            if overrides is not None and len(overrides):
                ov=overrides[(overrides.game_id==game.game_id)&(overrides.team==team)]
                for o in ov.itertuples(index=False):
                    if o.status=='OUT_CONFIRMED':
                        matched=cands.player_id.eq(o.player_id)
                        if matched.any():cands.loc[matched,'excluded_verified_out']=True
            if 'excluded_verified_out' not in cands.columns:cands['excluded_verified_out']=False
            cands['excluded_verified_out']=cands['excluded_verified_out'].fillna(False).astype(bool)
            cands=cands[~cands.excluded_verified_out].copy()
            if not (cands.position=='RB').any():raise ValueError(f'No RB after confirmed OUT exclusions for {team}')
            # Recency-weighted per-game carries. Absences get zero, not omitted.
            weights=np.linspace(.7,1.3,len(weeks)); weights=weights/weights.sum()
            totals=team_weeks.set_index('week').reindex(weeks).carries.fillna(0).to_numpy(float)
            weighted_team=float(np.dot(totals,weights))
            wr=season_rows.pivot_table(index='player_id',columns='week',values='carries',aggfunc='sum',fill_value=0).reindex(columns=weeks,fill_value=0)
            avgplayer={pid:float(np.dot(wr.loc[pid].to_numpy(dtype=float),weights)) for pid in wr.index}
            cands['recent4_weighted_carries_per_game']=cands.player_id.map(avgplayer).fillna(0.).astype(float)
            cands['recent4_weighted_share']=cands.recent4_weighted_carries_per_game/max(weighted_team,1)
            cands['recent4_weighted_share']=cands.recent4_weighted_share.clip(0,1)
            # Simple quality gates; names and statuses remain provisional.
            if cands[cands.position=='RB'].recent4_weighted_carries_per_game.max()<=0:
                flags.append({'game_id':game.game_id,'team':team,'issue':'NO_PROVISIONAL_RB_HAS_PRIOR4_CARRIES'})
            if cands.recent4_weighted_share.sum()>1.000001:
                raise ValueError('Candidate carry shares exceed 100%: '+team)
            lead=(cands[cands.position=='RB'].sort_values(['recent4_weighted_carries_per_game','depth_rank','player_id'],ascending=[False,True,True]).iloc[0])
            # Human-reviewed pool is still not automated certification.
            qbranks=cands[cands.position=='QB'].depth_rank.dropna()
            if (qbranks==1).sum()!=1:flags.append({'game_id':game.game_id,'team':team,'issue':'NO_UNAMBIGUOUS_PROVISIONAL_QB1'})
            teams.append({'game_id':game.game_id,'team':team,'opponent':opp,'kickoff_utc':game.kickoff_utc,
                          'team_rush_mean_input':mu,'recent4_rush_mu':vol,'opponent_recent4_allowed':opp_allow,
                          'p4pass_rate':passrate,'lead_id':str(lead.player_id),'lead_name':str(lead.player_name),
                          'lead_prior_share':float(lead.recent4_weighted_share),'lead_p4_carries':float(lead.recent4_weighted_carries_per_game),
                          'historical_weeks_used':','.join(map(str,weeks)),'complete_active_roster_certified':False,
                          'starting_qb_certified':False,'bet_ready':False})
            for c in cands.itertuples(index=False):
                players.append({'game_id':game.game_id,'team':team,'player_id':str(c.player_id),'player_name':str(c.player_name),
                               'position':c.position,'depth_rank':c.depth_rank,
                               'recent4_weighted_share':float(c.recent4_weighted_share),
                               'recent4_weighted_carries_per_game':float(c.recent4_weighted_carries_per_game),
                               'availability':getattr(c,'availability','UNKNOWN_NOT_VERIFIED'),'reviewed_role':getattr(c,'role','')})
    return pd.DataFrame(teams),pd.DataFrame(players),pd.DataFrame(flags)


def draw_one_team(rng, teamrow, pframe, fit, volume, draw_count, model):
    players=pframe.sort_values(['position','player_id']).reset_index(drop=True)
    if (players.player_id==teamrow.lead_id).sum()!=1:raise ValueError('Lead identity absent from available pool')
    names=players.player_id.tolist()+['RESIDUAL_NON_ROSTER_OR_NON_RB']
    share=players.recent4_weighted_share.to_numpy(float)
    # Unseen players get minimal nonzero likelihood; this is a research prior, not verified usage.
    share=share + np.where(players.position.eq('RB').to_numpy(),.003,.001)
    if share.sum()>.98:share*=.98/share.sum()
    share=np.concatenate([share,[max(.005,1-share.sum())]]);share/=share.sum()
    # Same expected roster-weighted volume distribution for the A/B comparison.
    alpha=np.maximum(share*60,.08)
    probability_draws=rng.dirichlet(alpha,size=draw_count)
    counts=np.array([rng.multinomial(int(n),p) for n,p in zip(volume,probability_draws)],dtype=np.int16)
    lead_idx=names.index(teamrow.lead_id)
    rb_idx=np.where(players.position.eq('RB').to_numpy())[0]
    if model=='TWO_STAGE_ROLE_V0351':
        if len(rb_idx)>=2:
            X=pd.DataFrame([{'prior_share':float(np.clip(teamrow.lead_prior_share,.01,.95)),
                             'p4rushes':float(np.clip(teamrow.recent4_rush_mu,1,70)),
                             'p4lead':float(np.clip(teamrow.lead_p4_carries,0,70)),
                             'p4pass_rate':float(teamrow.p4pass_rate)}])[FEATURES]
            z=float(np.clip(fit['zero'].predict_proba(X.to_numpy(float))[0,1],0,.9))
            m=float(np.clip(fit['positive'].predict(X.to_numpy(float))[0],.01,.98))
            frac_rbs=np.maximum(share[rb_idx].sum(),.10)
            m_rbonly=float(np.clip(m/frac_rbs,.02,.97))
            k=float(fit['kappa'])
            q=rng.beta(max(.01,m_rbonly*k),max(.01,(1-m_rbonly)*k),size=draw_count)
            q=np.where(rng.random(draw_count)<z,0,q)
            nrbs=counts[:,rb_idx].sum(axis=1).astype(int)
            leadcounts=rng.binomial(nrbs,q).astype(np.int16)
            others=np.array([ix for ix in rb_idx if ix!=lead_idx])
            proportion=share[others]/max(share[others].sum(),1e-9)
            other_count=np.array([rng.multinomial(int(n),proportion) for n in (nrbs-leadcounts)],dtype=np.int16)
            counts[:,rb_idx]=0
            counts[:,lead_idx]=leadcounts
            counts[:,others]=other_count
    assert np.array_equal(counts.sum(axis=1),volume)
    return names,counts


def simulate(teams,players,fit,draws=N_DRAWS,seed=SEED):
    if draws<20000:raise ValueError('Must run 20,000 actual draws per game per model')
    rng=np.random.default_rng(seed)
    preds=[];team_preds=[];checks=[];raw={}
    for game_id,gt in teams.groupby('game_id',sort=True):
        if len(gt)!=2:raise ValueError('Each game needs two team sides: '+game_id)
        game_latent=rng.standard_normal(draws)
        for t in gt.itertuples(index=False):
            mu=float(t.team_rush_mean_input)
            # Common game pace, team-specific error; no simulated scores/possessions.
            vol=np.clip(np.rint(mu+2.2*game_latent+6*rng.standard_normal(draws)),0,70).astype(np.int16)
            pf=players[(players.game_id==game_id)&(players.team==t.team)]
            for model in ('RECENT_SHARE_RESEARCH_BASE','TWO_STAGE_ROLE_V0351'):
                # Separate random streams are used for A/B opportunity assignment, but
                # both share this exact team volume array on each simulation index.
                names,counts=draw_one_team(rng,t,pf,fit,vol,draws,model)
                raw[f'{game_id}__{t.team}__{model}']=counts
                record={'game_id':game_id,'team':t.team,'model':model,'n_sim_draws':draws,
                        'team_rush_mean':float(np.mean(vol)),'team_rush_p10':float(np.quantile(vol,.1)),
                        'team_rush_p90':float(np.quantile(vol,.9)),'complete_active_roster_certified':False,
                        'starting_qb_certified':False,'bet_ready':False}
                team_preds.append(record)
                checks.append({'game_id':game_id,'team':t.team,'model':model,
                    'team_conservation_failures':int(np.count_nonzero(counts.sum(axis=1)!=vol)),
                    'draws':draws,'roster_certified':False,'bet_ready':False})
                for j,pid in enumerate(names):
                    if pid.startswith('RESIDUAL_'):
                        pname='Unidentified / non-RB residual';pos='OTHER'
                    else:
                        row=pf[pf.player_id==pid].iloc[0];pname=row.player_name;pos=row.position
                    z=counts[:,j]
                    preds.append({'game_id':game_id,'team':t.team,'player_id':pid,'player_name':pname,'position':pos,
                      'model':model,'n_sim_draws':draws,'mean':float(z.mean()),'p10':float(np.quantile(z,.1)),
                      'p50':float(np.quantile(z,.5)),'p90':float(np.quantile(z,.9)),
                      'p_10plus':float(np.mean(z>=10)),'p_15plus':float(np.mean(z>=15)),
                      'p_20plus':float(np.mean(z>=20)),'p_positive':float(np.mean(z>0)),
                      'full_active_verified':False,'starting_qb_verified':False,'bet_ready':False})
    return pd.DataFrame(preds),pd.DataFrame(team_preds),pd.DataFrame(checks),raw


