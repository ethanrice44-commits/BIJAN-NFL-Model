"""V0363 roster-to-carry integration. Human-reviewed evidence is not automated certification.
Default: fail closed. No market-ready or automatically verified projections.
"""
import argparse, json, hashlib, re, zipfile, shutil
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlparse
import pandas as pd
import numpy as np
import carry_engine as engine
import roster_quality as qa

VERSION='BIJAN_V0363_ROSTER_INTEGRATION'
POSITIONS={'QB','RB','FB','WR','TE'}
KEY=['game_id','team','player_id']
REVIEW_COLS=KEY+['player_name','position','status','role','source_file','source_sha256','source_url','published_utc','captured_utc','reviewed_by']
TEAM_COLS=['game_id','team','kickoff_utc','complete_offensive_list_reviewed','source_file','source_sha256','source_url','published_utc','captured_utc','reviewed_by']

def utcnow(): return pd.Timestamp(datetime.now(timezone.utc))
def ts(v):
    t=pd.Timestamp(v)
    if pd.isna(t) or t.tzinfo is None: raise ValueError('Missing timezone-aware time')
    return t.tz_convert('UTC')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return pd.read_csv(p,dtype=str,keep_default_na=False)
def need(df, cols):
    if not set(cols)<=set(df): raise ValueError('Missing columns: '+str(set(cols)-set(df)))
def official(url):
    # URL allowlist is only a sanity check; reviewer must verify the document's origin/content.
    u=urlparse(url)
    return u.scheme=='https' and (u.hostname=='nfl.com' or (u.hostname or '').endswith('.nfl.com'))
def check_evidence(row, review, kickoff, now):
    if not official(row.source_url): raise ValueError('Use NFL.com official evidence (manual review)')
    p=(review/row.source_file).resolve()
    if review.resolve() not in p.parents or not p.is_file() or not p.stat().st_size: raise ValueError('Missing evidence capture')
    if sha(p)!=row.source_sha256: raise ValueError('Evidence hash mismatch')
    pub,cap=ts(row.published_utc),ts(row.captured_utc)
    if not (kickoff-pd.Timedelta(minutes=100)<=pub<=cap<=now<kickoff): raise ValueError('Evidence must be game-day and pre-kickoff')
    if not str(row.reviewed_by).strip(): raise ValueError('Missing human reviewer')

def review_team(g, team, candidate, review, rows, certs, now):
    kickoff=ts(g.kickoff)
    t=rows[(rows.game_id==g.id)&(rows.team==team)].copy()
    c=certs[(certs.game_id==g.id)&(certs.team==team)]
    if len(c)!=1 or c.iloc[0].complete_offensive_list_reviewed!='YES': raise ValueError('Complete offensive list not attested by reviewer')
    cert=c.iloc[0]
    if ts(cert.kickoff_utc)!=kickoff: raise ValueError('Official kickoff review mismatch')
    check_evidence(cert,review,kickoff,now)
    if t.empty or t.duplicated(KEY).any(): raise ValueError('Missing or duplicate player review')
    if not t.player_id.str.fullmatch(r'00-\d{7}').all() or not t.player_name.str.strip().ne('').all(): raise ValueError('Unresolved exact player identity')
    if not t.position.isin(POSITIONS).all() or not t.status.isin(['ACTIVE','INACTIVE','NOT_ELIGIBLE']).all(): raise ValueError('Unresolved status/position')
    for row in t.itertuples(index=False): check_evidence(row,review,kickoff,now)
    # Every provisional offensive player must be explicitly accounted for; review may add elevations/new players.
    required=candidate[candidate.research_current_candidate.astype(str).str.lower().eq('true')]
    if not set(required.player_id)<=set(t.player_id): raise ValueError('Candidate not reconciled in reviewed list')
    known=required.set_index('player_id')
    for p in t.itertuples(index=False):
        if p.player_id in known.index:
            k=known.loc[p.player_id]
            if k.position!=p.position: raise ValueError('Position conflict for '+p.player_id)
            if re.sub(r'[^a-z0-9]','',k.player_name.lower())!=re.sub(r'[^a-z0-9]','',p.player_name.lower()): raise ValueError('Name conflict for '+p.player_id)
    a=t[t.status.eq('ACTIVE')].copy()
    q=a[a.position.eq('QB')]
    if (q.role=='QB1').sum()!=1 or (q.role=='QB2').sum()!=1 or not q.role.isin(['QB1','QB2','QB_OTHER']).all(): raise ValueError('QB1 and QB2 not uniquely reviewed')
    if not a.position.eq('RB').any(): raise ValueError('No active RB')
    rb=a[a.position.eq('RB')]
    if not rb.role.isin(['RB1','RB2','RB_COMMITTEE','RB_OTHER']).all() or (rb.role=='RB1').sum()>1: raise ValueError('RB roles must be explicitly reviewed; use RB_COMMITTEE if unclear')
    a['depth_rank']=a.role.map({'QB1':1,'QB2':2,'RB1':1,'RB2':2})
    a['is_53man_candidate']=True # adapter flag includes reviewed elevations, not literal 53-man membership
    a['availability']='HUMAN_REVIEWED_ACTIVE'
    return a,t[~t.status.eq('ACTIVE')]

def prepare(capture,out,review=None,now=None):
    now=utcnow() if now is None else ts(now)
    capture=Path(capture);out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    if not (capture/'capture_manifest.json').exists():
        (out/'preflight_status.json').write_text(json.dumps({'status':'NO_CAPTURE','ready_games':0,'market_ready':False}));return pd.DataFrame(),pd.DataFrame(),pd.DataFrame()
    checks=json.loads((capture/'file_sha256.json').read_text())
    for f in ['capture_manifest.json','game_schedule.csv','candidate_pool.csv','simulation_gates.csv']:
        if f not in checks: raise ValueError('Required file missing from checksum manifest: '+f)
    issues=qa.verify_manifest(capture)
    if issues: raise ValueError('; '.join(issues))
    manifest=json.loads((capture/'capture_manifest.json').read_text())
    if manifest['mode']!='live': raise ValueError('Synthetic capture cannot feed prospective simulations')
    cap=ts(manifest['created_utc'])
    if cap>now: raise ValueError('Future capture')
    qa.quality_audit(capture,out/'qa')
    cand=read(out/'qa/candidate_pool_by_game.csv')
    schedule=read(capture/'game_schedule.csv')
    if schedule.id.duplicated().any(): raise ValueError('Duplicate game ID')
    if review is not None:
        review=Path(review);rows=read(review/'PLAYER_REVIEW.csv');certs=read(review/'TEAM_REVIEW.csv')
        need(rows,REVIEW_COLS);need(certs,TEAM_COLS)
    else: rows=pd.DataFrame(columns=REVIEW_COLS);certs=pd.DataFrame(columns=TEAM_COLS)
    gates=[];ready=[];pools=[];excluded=[];templates=[];team_templates=[]
    for g in schedule.itertuples(index=False):
        kickoff=ts(g.kickoff);mins=(kickoff-now).total_seconds()/60
        if mins<=0 or mins>180: continue
        gp=[];ge=[];gg=[]
        for team in (g.away,g.home):
            c=cand[(cand.game_id==g.id)&(cand.team==team)].copy()
            current=c[c.research_current_candidate.str.lower().eq('true')].copy()
            for r in current.itertuples(index=False):
                templates.append(dict(game_id=g.id,team=team,player_id=r.player_id,player_name=r.player_name,position=r.position,status='',role=''))
            team_templates.append(dict(game_id=g.id,team=team,kickoff_utc=g.kickoff))
            try:
                if mins>100 or now-cap>pd.Timedelta(minutes=90): raise ValueError('Outside final review window or stale collector snapshot')
                if review is None: raise ValueError('No reviewed official game-day evidence supplied')
                a,e=review_team(g,team,c,review,rows,certs,now);gp.append(a);ge.append(e)
                gg.append(dict(game_id=g.id,team=team,status='HUMAN_REVIEW_PASSED',reason='',market_ready=False))
            except ValueError as exc: gg.append(dict(game_id=g.id,team=team,status='BLOCKED',reason=str(exc),market_ready=False))
        if len(gp)==2 and not pd.concat(gp).player_id.duplicated().any():
            ready.append(dict(game_id=g.id,away=g.away,home=g.home,kickoff_utc=g.kickoff));pools.extend(gp);excluded.extend(ge)
        else:
            for x in gg:
                if x['status']=='HUMAN_REVIEW_PASSED': x.update(status='BLOCKED',reason='Opponent not cleared or cross-team identity conflict')
        gates.extend(gg)
    pd.DataFrame(gates,columns=['game_id','team','status','reason','market_ready']).to_csv(out/'PREFLIGHT_GATES.csv',index=False)
    pd.DataFrame(templates).reindex(columns=REVIEW_COLS).to_csv(out/'PLAYER_REVIEW_TEMPLATE.csv',index=False)
    pd.DataFrame(team_templates).reindex(columns=TEAM_COLS).to_csv(out/'TEAM_REVIEW_TEMPLATE.csv',index=False)
    games=pd.DataFrame(ready,columns=['game_id','away','home','kickoff_utc'])
    pool=pd.concat(pools,ignore_index=True) if pools else pd.DataFrame(columns=REVIEW_COLS)
    ex=pd.concat(excluded,ignore_index=True) if excluded else pd.DataFrame(columns=REVIEW_COLS)
    pool.to_csv(out/'ENGINE_PLAYER_POOL.csv',index=False);ex.to_csv(out/'EXCLUDED_PLAYERS.csv',index=False)
    (out/'preflight_status.json').write_text(json.dumps({'status':'REVIEWED_RESEARCH_INPUT_READY' if len(games) else 'BLOCKED_NO_REVIEWED_GAMES','ready_games':len(games),'market_ready':False,'capture_utc':str(cap),'checked_utc':str(now)},indent=2))
    return games,pool,ex

def run(capture,out,review,simulate=False,stats_csv=None):
    out=Path(out)
    if simulate and (Path(capture).resolve() in out.resolve().parents or (review and Path(review).resolve() in out.resolve().parents)): raise ValueError('Simulation output must be separate from capture and review directories')
    if out.exists() and any(out.iterdir()): raise FileExistsError('Use a fresh output directory')
    games,pool,ex=prepare(capture,out,review)
    if not simulate or games.empty: return
    # One current week per run. Same-week final results are never inputs.
    ids=games.game_id.str.extract(r'^(\d{4})_(\d{2})_')
    if ids.isna().any().any() or len(ids.drop_duplicates())!=1: raise ValueError('Select a single NFL season/week')
    season,week=map(int,ids.iloc[0]); now=utcnow()
    if stats_csv: raw=pd.read_csv(stats_csv,dtype={'player_id':str})
    else:
        import nflreadpy as nfl
        raw=nfl.load_player_stats(season,summary_level='week').to_pandas()
    data=engine.prep_stats(raw,season,week)
    if data.week.max()<week-1: raise ValueError('Player statistics stale')
    Hpath=Path(__file__).parent/'data/HISTORY_2022_2025.csv'; H=pd.read_csv(Hpath)
    if season<=2025: raise ValueError('Historical fitting includes 2025; not an as-of historical backtest')
    fit=engine.fit_v0351_historical(H)
    teams,players,flags=engine.build_features(data,games,pool)
    pred,team_pred,checks,draws=engine.simulate(teams,players,fit)
    if checks.team_conservation_failures.sum(): raise ValueError('Carry totals do not reconcile')
    if len(pred.merge(ex[KEY],on=KEY)): raise ValueError('Excluded player leaked into draws')
    if utcnow()>=min(map(ts,games.kickoff_utc)): raise ValueError('Run crossed kickoff: no pregame freeze')
    for f,d in [('PLAYER_FORECASTS',pred),('TEAM_FORECASTS',team_pred),('DRAW_CHECKS',checks),('FEATURES',teams),('PLAYER_FEATURES',players),('WARNINGS',flags)]: d.to_csv(out/(f+'.csv'),index=False)
    np.savez_compressed(out/'RAW_CARRY_DRAWS.npz',**draws)
    data.to_csv(out/'PREGAME_STATS_USED.csv',index=False)
    shutil.copytree(capture,out/'COLLECTOR_CAPTURE',ignore=shutil.ignore_patterns('qa','integration'))
    shutil.copytree(review,out/'REVIEW_EVIDENCE')
    with pd.ExcelWriter(out/'BIJAN_Carry_Research.xlsx',engine='openpyxl') as w:
        pred.to_excel(w,sheet_name='Player forecasts',index=False);team_pred.to_excel(w,sheet_name='Team forecasts',index=False);checks.to_excel(w,sheet_name='Checks',index=False);ex.to_excel(w,sheet_name='Excluded players',index=False)
    frozen=utcnow()
    if frozen>=min(map(ts,games.kickoff_utc)): raise ValueError('Export crossed kickoff: no pregame freeze')
    manifest={'version':VERSION,'classification':'HUMAN_REVIEWED_ROSTER_RESEARCH_ONLY','bet_ready':False,'frozen_utc':str(frozen),'games':games.game_id.tolist(),'historical_training_sha256':sha(Hpath),'code_sha256':{n:sha(Path(__file__).parent/n) for n in ['pipeline.py','carry_engine.py','roster_quality.py','roster_runner.py']},'limitations':['Human attestation is not automated source authentication','Residual carries remain anonymous','RB workload model unchanged and unvalidated','QB roles are recorded, not a new calibrated QB usage model'],'files':{str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}}
    (out/'IMMUTABLE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--capture',required=True);p.add_argument('--output',required=True);p.add_argument('--review');p.add_argument('--simulate',action='store_true');p.add_argument('--stats-csv');a=p.parse_args();run(a.capture,a.output,a.review,a.simulate,a.stats_csv)
