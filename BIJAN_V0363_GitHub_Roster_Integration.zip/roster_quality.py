#!/usr/bin/env python3
"""BIJAN V0.3.5.5: immutable source audit + *research-only* game-keyed player pools.

Runs OFFLINE on a real GitHub Actions export. Does not infer active status from
absence on an inactive list. No automatic roster certification is performed.
"""
from __future__ import annotations
import argparse, hashlib, io, json, re, zipfile
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd

STATUS_CLASS = {
    'ACT':'FIFTY_THREE_MAN_CANDIDATE',
    'DEV':'PRACTICE_SQUAD_ELEVATION_UNVERIFIED',
    'PS':'PRACTICE_SQUAD_ELEVATION_UNVERIFIED',
    'RES':'RESERVE_NOT_NORMAL_CANDIDATE',
    'IR':'RESERVE_NOT_NORMAL_CANDIDATE',
    'CUT':'HISTORICAL_CUT',
    'RET':'HISTORICAL_RETIRED',
    'EXE':'HISTORICAL_EXEMPT',
    'INA':'ROSTER_CODE_INACTIVE_REVIEW',
    'UNKNOWN':'DEPTH_ONLY_UNVERIFIED',
}
COLUMNS = ['game_id','team','player_id','player_name','position','roster_status',
           'roster_bucket','depth_rank','depth_asof_utc','availability','evidence','mapping_status']

def data_bytes(z_or_path, name):
    if isinstance(z_or_path, zipfile.ZipFile): return z_or_path.read(name)
    return (Path(z_or_path)/name).read_bytes()

def is_real_text(series):
    return series.astype(str).str.strip().ne('') & (~series.astype(str).str.strip().str.lower().isin(['none','nan','null','n/a','<na>']))

def parse_dt(value):
    x=pd.to_datetime(value, utc=True, errors='coerce')
    return x

def verify_manifest(root):
    """Read source hashes before examining any contents; return integrity failures."""
    problems=[]
    try: checks=json.loads(data_bytes(root,'file_sha256.json'))
    except (OSError,KeyError,ValueError) as e: return [f'CHECKSUM_MANIFEST_MISSING_OR_INVALID: {e}']
    for filename,expected in checks.items():
        try:
            got=hashlib.sha256(data_bytes(root,filename)).hexdigest()
            if got!=expected:problems.append(f'SOURCE_SHA256_MISMATCH: {filename}')
        except (OSError,KeyError):problems.append(f'SOURCE_FILE_MISSING: {filename}')
    return problems

def csv(root, name):
    return pd.read_csv(io.BytesIO(data_bytes(root,name)), dtype=str, keep_default_na=False)

def quality_audit(source, out, max_depth_age_days=14):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    z = zipfile.ZipFile(source) if str(source).lower().endswith('.zip') else None
    root = z if z is not None else Path(source)
    try:
        # Skipped scheduled polls still produce an artifact, but have no candidate CSV.
        def exists(name):
            return name in root.namelist() if isinstance(root,zipfile.ZipFile) else (Path(root)/name).exists()
        if not (exists('candidate_pool.csv') and exists('game_schedule.csv')):
            result={'status':'NO_ROSTER_CAPTURE','games':0,'team_sides':0,'reason':'Collector skipped or failed before producing a game roster; not verified.'}
            (out/'quality_summary.json').write_text(json.dumps(result,indent=2))
            return result
        source_issues=verify_manifest(root)
        if source_issues:
            (out/'quality_summary.json').write_text(json.dumps({'status':'SOURCE_INTEGRITY_FAILED','problems':source_issues},indent=2))
            raise ValueError('; '.join(source_issues))
        try: raw=csv(root,'candidate_pool.csv'); schedule=csv(root,'game_schedule.csv')
        except (OSError,KeyError):
            (out/'quality_summary.json').write_text(json.dumps({'status':'NO_ROSTER_CAPTURE','reason':'No candidate_pool.csv or game_schedule.csv; skipped/error run, not certified.'},indent=2))
            return {'status':'NO_ROSTER_CAPTURE','games':0,'team_sides':0}
        manifest=json.loads(data_bytes(root,'capture_manifest.json'))
        capture=parse_dt(manifest.get('created_utc'))
        if pd.isna(capture): raise ValueError('Capture timestamp missing or invalid')
        if set(['id','home','away','kickoff'])-set(schedule.columns): raise ValueError('Game schedule columns missing')
        if set(['team','player_id','player_name','position','roster_status'])-set(raw.columns):raise ValueError('Candidate pool columns missing')
        schedule=schedule.drop_duplicates('id',keep='first').copy()
        schedule['kickoff_dt']=pd.to_datetime(schedule.kickoff,utc=True,errors='coerce')
        if schedule['kickoff_dt'].isna().any(): raise ValueError('Kickoff datetime invalid')
        if (schedule.kickoff_dt<=capture).any(): raise ValueError('Archive contains games already kicked off at capture')
        # Legacy V0354 exports did not contain game_id in candidate_pool.
        # They repeated the exact same team snapshot for every scheduled team appearance.
        # We can safely reconstruct ONLY when repeated team/id rows are IDENTICAL.
        raw=raw.copy()
        had_game_id='game_id' in raw.columns
        conflicts=[]
        if had_game_id:
            raw=raw.drop_duplicates()
            valid_ids=raw.loc[raw.player_id.ne('')]
            for (game,team,pid),group in valid_ids.groupby(['game_id','team','player_id'],dropna=False):
                if len(group)>1:conflicts.append((game,team,pid))
            expanded=raw
        else:
            cols=sorted(raw.columns.tolist())
            raw=raw.drop_duplicates(subset=cols)
            valid=raw[raw.player_id.ne('')]
            conflicted=valid[valid.duplicated(['team','player_id'],keep=False)]
            conflicts=[('LEGACY_UNATTRIBUTABLE',team,pid) for team,pid in conflicted[['team','player_id']].drop_duplicates().itertuples(index=False,name=None)]
            # Conflicting legacy observations cannot be mapped to a particular game.
            raw=raw[~((raw.player_id.ne('')) & raw.set_index(['team','player_id']).index.isin([(t,p) for _,t,p in conflicts]))]
            expanded=pd.concat([raw.assign(game_id=g.id).loc[lambda d:d.team.isin([g.home,g.away])]
                              for g in schedule.itertuples()],ignore_index=True) if len(schedule) else raw.assign(game_id='')
        if 'game_id' not in expanded.columns:expanded['game_id']=''
        sched_idx={(g.id,g.home):g.kickoff_dt for g in schedule.itertuples()}
        sched_idx.update({(g.id,g.away):g.kickoff_dt for g in schedule.itertuples()})
        invalid_game=expanded[~expanded.apply(lambda r:(r['game_id'],r['team']) in sched_idx,axis=1)]
        if len(invalid_game):raise ValueError(f'{len(invalid_game)} candidate rows do not match a game/team')
        expanded=expanded.reset_index(drop=True).copy()
        expanded['candidate_key']=[f'C{i:06d}' for i in range(len(expanded))]
        expanded['source_status_class']=expanded.roster_status.map(STATUS_CLASS).fillna('UNRECOGNIZED_SOURCE_CODE')
        expanded['id_present']=is_real_text(expanded.player_id) & expanded.player_id.astype(str).str.match(r'^00-\d{7}$')
        expanded['name_present']=is_real_text(expanded.player_name)
        expanded['is_53man_candidate']=expanded.source_status_class.eq('FIFTY_THREE_MAN_CANDIDATE')
        expanded['depth_asof_dt']=pd.to_datetime(expanded.get('depth_asof_utc',''),utc=True,errors='coerce')
        expanded['depth_age_days']=((capture-expanded.depth_asof_dt).dt.total_seconds()/86400).round(1)
        expanded['depth_fresh']=(expanded.depth_age_days.ge(0)&expanded.depth_age_days.le(max_depth_age_days))
        expanded['rank_number']=pd.to_numeric(expanded.get('depth_rank',''),errors='coerce')
        expanded['safe_depth_rank']=expanded.rank_number.where(expanded.depth_fresh & expanded.rank_number.gt(0))
        expanded['identity_conflict']=expanded.apply(lambda r:(r['game_id'],r['team'],r['player_id']) in conflicts or ('LEGACY_UNATTRIBUTABLE',r['team'],r['player_id']) in conflicts,axis=1)
        expanded['research_current_candidate']=expanded.is_53man_candidate & expanded.id_present & expanded.name_present & (~expanded.identity_conflict)
        expanded['eligible_for_engine']=False
        expanded['bet_ready']=False
        expanded['review_reasons']=expanded.apply(lambda r: '; '.join(
            ([f"STATUS_{r.source_status_class}"] if not r.is_53man_candidate else [])+
            (['MISSING_OR_INVALID_PLAYER_ID'] if not r.id_present else [])+
            (['MISSING_PLAYER_NAME'] if not r.name_present else [])+
            (['DEPTH_STALE_OR_UNKNOWN'] if not r.depth_fresh else [])+
            (['CONFLICTING_IDENTITIES'] if r.identity_conflict else [])
        ),axis=1)
        # QA output is not eligible output. Only data-integrity + provisional role candidates.
        expanded=expanded.drop(columns=['depth_asof_dt','rank_number'])
        expanded.to_csv(out/'candidate_pool_by_game.csv',index=False)
        expanded[expanded.review_reasons.ne('')].to_csv(out/'roster_watchlist.csv',index=False)
        current=expanded[expanded.research_current_candidate].copy()
        current.to_csv(out/'provisional_53man_candidates.csv',index=False)
        current[current.position.isin(['QB','RB','HB','FB'])].to_csv(out/'provisional_qb_rb_only.csv',index=False)
        expanded[(~expanded.id_present)|(~expanded.name_present)].to_csv(out/'unresolved_identities.csv',index=False)
        issues=[]; reviews=[]
        # Multiple *active roster* team assignments for same GSIS ID are a red flag.
        collisions=current.groupby('player_id').team.nunique().loc[lambda s:s>1]
        for pid in collisions.index:
            issues.append({'game_id':'ALL','team':'MULTIPLE','issue':'ACTIVE_ID_ON_MULTIPLE_TEAMS','player_id':pid})
        for game in schedule.itertuples():
            for team in [game.away,game.home]:
                t=expanded[(expanded.game_id==game.id)&(expanded.team==team)]
                usable=t[t.research_current_candidate]
                q=usable[usable.position.eq('QB')].copy()
                rb=usable[usable.position.isin(['RB','HB'])].copy()
                fb=usable[usable.position.eq('FB')].copy()
                def role_candidate(group,ordinal):
                    ranked=group[group.safe_depth_rank.notna()]
                    ranked=ranked.sort_values(['safe_depth_rank','player_id'])
                    if len(ranked)<ordinal:return ('','',False,'NOT_ENOUGH_FRESH_RANKS')
                    row=ranked.iloc[ordinal-1]
                    rank=row.safe_depth_rank
                    # Any equal rank means unresolved role ordering.
                    if (ranked.safe_depth_rank==rank).sum()>1: return ('','',False,'TIED_DEPTH_RANK')
                    return (row.player_id,row.player_name,True,'PROVISIONAL_DEPTH_ONLY')
                qb1=role_candidate(q,1);qb2=role_candidate(q,2);rb1=role_candidate(rb,1)
                reasons=[]
                if len(q)<2:reasons.append('FEWER_THAN_2_53MAN_QB_CANDIDATES')
                if not qb1[2]:reasons.append('QB1_'+qb1[3])
                if not qb2[2]:reasons.append('QB2_'+qb2[3])
                if len(rb)<1:reasons.append('NO_53MAN_RB_CANDIDATE')
                if not rb1[2]:reasons.append('RB1_'+rb1[3])
                if len(t[~t.id_present]):reasons.append('UNRESOLVED_IDENTITY_REVIEW')
                if len(t[t.source_status_class.eq('UNRECOGNIZED_SOURCE_CODE')]):reasons.append('UNKNOWN_ROSTER_STATUS_CODES')
                reasons.append('OFFICIAL_INACTIVES_NOT_CERTIFIED')
                reasons.append('QB_STARTER_AND_RB_ROLES_NOT_CONFIRMED')
                if len(t[t.identity_conflict]):reasons.append('CONFLICTING_PLAYER_IDENTITIES')
                reviews.append({'game_id':game.id,'team':team,'kickoff_utc':game.kickoff,
                                'player_rows':len(t),'provisional_53man':len(usable),
                                'qb_candidates':len(q),'rb_candidates':len(rb),'fb_candidates':len(fb),
                                'practice_squad_candidates':sum(t.source_status_class=='PRACTICE_SQUAD_ELEVATION_UNVERIFIED'),
                                'reserve_candidates':sum(t.source_status_class=='RESERVE_NOT_NORMAL_CANDIDATE'),
                                'historical_depth_only':sum(t.source_status_class=='DEPTH_ONLY_UNVERIFIED'),
                                'missing_or_bad_ids':sum(~t.id_present),
                                'stale_or_missing_depth':sum(~t.depth_fresh),
                                'provisional_qb1':qb1[1],'provisional_qb2':qb2[1],'provisional_rb1':rb1[1],
                                'unverified_player_count':len(t),'bet_ready':False,
                                'review_reasons':'; '.join(dict.fromkeys(reasons))})
        for x in conflicts:issues.append({'game_id':x[0],'team':x[1],'issue':'CONFLICTING_LEGACY_CANDIDATE_RECORDS','player_id':x[2]})
        pd.DataFrame(reviews).to_csv(out/'team_game_review.csv',index=False)
        pd.DataFrame([r for r in reviews if 'RB1_TIED_DEPTH_RANK' in r['review_reasons'] or 'QB2_TIED_DEPTH_RANK' in r['review_reasons']]).to_csv(out/'ambiguous_depth_charts.csv',index=False)
        pd.DataFrame(issues,columns=['game_id','team','issue','player_id']).to_csv(out/'identity_conflicts.csv',index=False)
        summary={'schema':'BIJAN_V0355_ROSTER_QA','status':'RESEARCH_ONLY_UNVERIFIED',
                 'source_created_utc':manifest['created_utc'],'legacy_game_id_reconstruction':not had_game_id,
                 'games':len(schedule),'team_sides':len(reviews),'export_candidate_rows':len(expanded),
                 'source_rows':len(csv(root,'candidate_pool.csv')),
                 'exact_repeats_in_source':len(csv(root,'candidate_pool.csv'))-len(csv(root,'candidate_pool.csv').drop_duplicates()),
                 'candidate_53man_rows':int(expanded.is_53man_candidate.sum()),
                 'missing_or_bad_player_id_rows':int((~expanded.id_present).sum()),
                 'missing_player_name_rows':int((~expanded.name_present).sum()),
                 'stale_or_unknown_depth_rows':int((~expanded.depth_fresh).sum()),
                 'qb1_candidate_unambiguous':sum(bool(r['provisional_qb1']) for r in reviews),
                 'qb2_candidate_unambiguous':sum(bool(r['provisional_qb2']) for r in reviews),
                 'rb1_candidate_unambiguous':sum(bool(r['provisional_rb1']) for r in reviews),
                 'unresolved_identity_conflicts':len(issues),
                 'bet_ready_teams':0,'source_sha256_verified':True,
                 'notes':['ACT denotes a roster candidate, not official game-day active',
                          'Historical depth-only names are not automatically eligible',
                          'Source feed does not certify inactives/elevations/starter assignments']}
        (out/'quality_summary.json').write_text(json.dumps(summary,indent=2))
        return summary
    finally:
        if z is not None: z.close()

def main():
    a=argparse.ArgumentParser();a.add_argument('--input',help='Directory created by roster_runner.py or downloaded GitHub ZIP',required=True)
    a.add_argument('--output',default='output/qa');args=a.parse_args()
    summary=quality_audit(args.input,args.output)
    print(json.dumps({k:summary[k] for k in ('status','games','team_sides')},indent=2))

if __name__=='__main__': main()
