"""Network-free integration test: synthetic source bytes exercise --mode live."""
import datetime as dt
import io, json, os, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import pandas as pd
import roster_runner as r
import roster_quality as qa

class OfflineLiveIntegration(unittest.TestCase):
    def test_manual_capture_produces_game_keyed_research_only_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            now=dt.datetime(2026,11,19,1,43,tzinfo=dt.timezone.utc)
            sch=pd.DataFrame([{'game_id':'2026_11_IND_HOU','season':'2026','gameday':'2026-11-19',
                              'gametime':'20:15','home_team':'HOU','away_team':'IND'}])
            roster=[];depth=[]
            for team in ('IND','HOU'):
                for i,(pos,rank) in enumerate([('QB',1),('QB',2),('RB',1),('RB',2)]):
                    pid=f'00-{len(roster)+1:07d}'
                    roster.append(dict(team=team,gsis_id=pid,position=pos,full_name=f'{team} Test {i}',status='ACT'))
                    depth.append(dict(team=team,gsis_id=pid,pos_abb=pos,pos_rank=rank,dt='2026-11-18T16:00:00Z'))
            # Mock parquet decoding so the test works without optional pyarrow
            # while still exercising the collector's complete live path.
            b={'games.csv':sch.to_csv(index=False).encode(), 'roster_2026.parquet':b'ROSTER_FIXTURE',
               'depth_charts_2026.parquet':b'DEPTH_FIXTURE'}
            def read_fixture(stream):
                payload=stream.read()
                if payload==b'ROSTER_FIXTURE':return pd.DataFrame(roster)
                if payload==b'DEPTH_FIXTURE':return pd.DataFrame(depth)
                raise AssertionError('Unexpected parquet input')
            def fetch(url,headers=None):
                return b[url.rsplit('/',1)[-1]]
            oldargv=sys.argv
            try:
                sys.argv=['roster_runner.py','--mode','live','--season','2026','--output',str(Path(tmp)/'output')]
                with patch.object(r,'utcnow',return_value=now),patch.object(r,'fetch_bytes',side_effect=fetch),patch.object(r.pd,'read_parquet',side_effect=read_fixture),patch.dict(os.environ,{'GITHUB_EVENT_NAME':'workflow_dispatch','BIJAN_SPORTRADAR_KEY':''}):
                    r.main()
            finally:sys.argv=oldargv
            pool=pd.read_csv(Path(tmp)/'output/candidate_pool.csv')
            self.assertEqual(set(pool.game_id),{'2026_11_IND_HOU'})
            self.assertEqual(len(pool),8)
            self.assertEqual(len(pd.read_csv(Path(tmp)/'output/verified_players_for_engine.csv')),0)
            summary=qa.quality_audit(Path(tmp)/'output',Path(tmp)/'qa')
            self.assertEqual(summary['games'],1)
            self.assertEqual(summary['team_sides'],2)
            self.assertEqual(summary['qb1_candidate_unambiguous'],2)
            self.assertEqual(summary['qb2_candidate_unambiguous'],2)
            self.assertEqual(summary['rb1_candidate_unambiguous'],2)
            self.assertEqual(summary['bet_ready_teams'],0)

if __name__=='__main__': unittest.main()
