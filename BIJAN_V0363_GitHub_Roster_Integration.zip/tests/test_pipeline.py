import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
import pandas as pd
import numpy as np
import pipeline as p

NOW=pd.Timestamp('2026-11-26T16:45:00Z')
KICK='2026-11-26T18:00:00Z'
GAME='2026_12_AAA_BBB'
class Integration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name); self.cap=self.root/'capture';self.cap.mkdir();self.review=self.root/'review';self.review.mkdir()
        self.rows=[];self.candidates=[];self.cert=[]
        src=self.review/'fixture.txt';src.write_text('SYNTHETIC TEST ONLY — not official evidence')
        ev=dict(source_file=src.name,source_sha256=p.sha(src),source_url='https://www.nfl.com/test-fixture',published_utc='2026-11-26T16:30:00Z',captured_utc='2026-11-26T16:40:00Z',reviewed_by='synthetic test')
        n=0
        for team in ['AAA','BBB']:
            for pos,role,status,bucket in [('QB','QB1','ACTIVE','ACT'),('QB','QB2','ACTIVE','ACT'),('RB','RB1','INACTIVE','ACT'),('RB','RB1','ACTIVE','ACT'),('RB','RB2','ACTIVE','DEV'),('WR','','ACTIVE','ACT'),('RB','','NOT_ELIGIBLE','DEV')]:
                n+=1;pid=f'00-{n:07d}';name=f'{team} player {n}'
                self.candidates.append(dict(game_id=GAME,team=team,player_id=pid,player_name=name,position=pos,roster_status=bucket,roster_bucket='ROSTER_CANDIDATE' if bucket=='ACT' else 'PRACTICE_SQUAD',depth_rank=1,depth_asof_utc='2026-11-25T16:00:00Z',availability='UNKNOWN_NOT_VERIFIED',evidence='synthetic',mapping_status='NOT_YET_MATCHED'))
                self.rows.append(dict(game_id=GAME,team=team,player_id=pid,player_name=name,position=pos,role=role,status=status,**ev))
            self.cert.append(dict(game_id=GAME,team=team,kickoff_utc=KICK,complete_offensive_list_reviewed='YES',**ev))
        pd.DataFrame(self.candidates).to_csv(self.cap/'candidate_pool.csv',index=False)
        pd.DataFrame([dict(id=GAME,away='AAA',home='BBB',kickoff=KICK)]).to_csv(self.cap/'game_schedule.csv',index=False)
        pd.DataFrame([dict(game_id=GAME,team='AAA',status='BLOCKED'),dict(game_id=GAME,team='BBB',status='BLOCKED')]).to_csv(self.cap/'simulation_gates.csv',index=False)
        (self.cap/'capture_manifest.json').write_text(json.dumps(dict(mode='live',created_utc='2026-11-26T16:40:00Z')))
        (self.cap/'file_sha256.json').write_text(json.dumps({f.name:p.sha(f) for f in self.cap.iterdir()}))
        self.write_review()
    def write_review(self):
        pd.DataFrame(self.rows).to_csv(self.review/'PLAYER_REVIEW.csv',index=False);pd.DataFrame(self.cert).to_csv(self.review/'TEAM_REVIEW.csv',index=False)
    def prepare(self,review=True,now=NOW): return p.prepare(self.cap,self.root/'out',self.review if review else None,now)
    def test_no_evidence_blocks_both(self):
        g,a,e=self.prepare(False);self.assertTrue(g.empty and a.empty);self.assertEqual(len(pd.read_csv(self.root/'out/PREFLIGHT_GATES.csv')),2)
    def test_review_excludes_and_includes_elevated(self):
        g,a,e=self.prepare();self.assertEqual(len(g),1);self.assertEqual(len(a),10);self.assertEqual(len(e),4);self.assertIn('00-0000005',set(a.player_id));self.assertNotIn('00-0000003',set(a.player_id))
    def test_missing_candidate_blocks_both(self):
        self.rows.pop(2);self.write_review();self.assertTrue(self.prepare()[0].empty)
    def test_late_capture_blocks(self):
        self.rows[0]['captured_utc']='2026-11-26T18:01:00Z';self.write_review();self.assertTrue(self.prepare()[0].empty)
    def test_postkickoff_blocks(self): self.assertTrue(self.prepare(now=pd.Timestamp('2026-11-26T18:01:00Z'))[0].empty)
    def test_bad_evidence_hash_blocks(self):
        self.rows[0]['source_sha256']='bad';self.write_review();self.assertTrue(self.prepare()[0].empty)
    def test_qb_role_ambiguity_blocks(self):
        self.rows[1]['role']='QB1';self.write_review();self.assertTrue(self.prepare()[0].empty)
    def test_full_run_real_engine_20k(self):
        stats=[]
        for row in self.rows:
            for week in range(7,12):
                stats.append(dict(season=2026,week=week,team=row['team'],opponent_team='BBB' if row['team']=='AAA' else 'AAA',player_id=row['player_id'],player_name=row['player_name'],position=row['position'],carries=12 if row['status']=='INACTIVE' else (5 if row['position']=='RB' else 1),attempts=30 if row['role']=='QB1' else 0))
        # sentinel from target week, must not be used
        stats.append(dict(stats[0],week=12,carries=9999))
        path=self.root/'stats.csv';pd.DataFrame(stats).to_csv(path,index=False)
        out=self.root/'run'
        with patch.object(p,'utcnow',return_value=NOW): p.run(self.cap,out,self.review,True,str(path))
        pred=pd.read_csv(out/'PLAYER_FORECASTS.csv');checks=pd.read_csv(out/'DRAW_CHECKS.csv')
        self.assertEqual(len(checks),4);self.assertEqual(checks.team_conservation_failures.sum(),0)
        self.assertTrue((checks.draws==20000).all());self.assertFalse(pred.bet_ready.any());self.assertNotIn('00-0000003',set(pred.player_id));self.assertIn('00-0000005',set(pred.player_id))
        self.assertEqual(pd.read_csv(out/'PREGAME_STATS_USED.csv').week.max(),11)
        self.assertTrue((out/'IMMUTABLE_MANIFEST.json').exists())
if __name__=='__main__': unittest.main()
