import io, json, tempfile, unittest, zipfile, hashlib
from pathlib import Path
import pandas as pd
import roster_quality as q

class QualityTests(unittest.TestCase):
    def build_small(self,base):
        base=Path(base)
        candidates=pd.DataFrame([
          dict(team='AAA',player_id='00-0000001',player_name='QB One',position='QB',roster_status='ACT',depth_rank='1',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='AAA',player_id='00-0000002',player_name='QB Two',position='QB',roster_status='ACT',depth_rank='2',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='AAA',player_id='00-0000003',player_name='RB One',position='RB',roster_status='ACT',depth_rank='1',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='AAA',player_id='00-0000004',player_name='RB Two',position='RB',roster_status='ACT',depth_rank='1',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='AAA',player_id='00-0000005',player_name='RB Reserve',position='RB',roster_status='DEV',depth_rank='3',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='AAA',player_id='None',player_name='None',position='RB',roster_status='UNKNOWN',depth_rank='4',depth_asof_utc='2026-09-01T00:00:00Z'),
          dict(team='BBB',player_id='00-0000006',player_name='QB Three',position='QB',roster_status='ACT',depth_rank='1',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='BBB',player_id='00-0000007',player_name='QB Four',position='QB',roster_status='ACT',depth_rank='2',depth_asof_utc='2026-11-18T00:00:00Z'),
          dict(team='BBB',player_id='00-0000008',player_name='RB Three',position='RB',roster_status='ACT',depth_rank='1',depth_asof_utc='2026-11-18T00:00:00Z'),
        ])
        pd.DataFrame([dict(id='FUTURE',home='AAA',away='BBB',kickoff='2026-11-20T01:15:00Z')]).to_csv(base/'game_schedule.csv',index=False)
        candidates.to_csv(base/'candidate_pool.csv',index=False)
        (base/'capture_manifest.json').write_text(json.dumps(dict(created_utc='2026-11-19T01:43:28Z',schema='test')))
        checks={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.name!='file_sha256.json'}
        (base/'file_sha256.json').write_text(json.dumps(checks))
    def test_fails_closed_and_blocks_tied_rb(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'source'; source.mkdir();self.build_small(source)
            result=q.quality_audit(source,Path(d)/'qa')
            self.assertEqual(result['team_sides'],2)
            self.assertEqual(result['bet_ready_teams'],0)
            self.assertEqual(result['missing_player_name_rows'],1)
            pool=pd.read_csv(Path(d)/'qa/candidate_pool_by_game.csv')
            self.assertFalse(pool.eligible_for_engine.any())
            self.assertFalse(pool.bet_ready.any())
            d1=pd.read_csv(Path(d)/'qa/team_game_review.csv').set_index('team')
            self.assertTrue('RB1_TIED_DEPTH_RANK' in d1.loc['AAA','review_reasons'])
            self.assertTrue(pd.isna(d1.loc['AAA','provisional_rb1']))
            self.assertEqual(d1.loc['AAA','provisional_qb1'],'QB One')
    def test_checksum_detects_tampering(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'source';source.mkdir();self.build_small(source)
            with open(source/'candidate_pool.csv','a') as f:f.write('TAMPER\n')
            with self.assertRaisesRegex(ValueError,'SOURCE_SHA256_MISMATCH'):
                q.quality_audit(source,Path(d)/'qa')
    def test_no_capture_emits_diagnostic_not_fake_data(self):
        with tempfile.TemporaryDirectory() as d:
            result=q.quality_audit(d,Path(d)/'qa')
            self.assertEqual(result['status'],'NO_ROSTER_CAPTURE')
            self.assertTrue((Path(d)/'qa/quality_summary.json').exists())
    def test_real_text_placeholders(self):
        s=pd.Series(['None','nan','null','','00-1234567','Smith','N/A'])
        self.assertEqual(q.is_real_text(s).tolist(),[False,False,False,False,True,True,False])

if __name__=='__main__':unittest.main()
