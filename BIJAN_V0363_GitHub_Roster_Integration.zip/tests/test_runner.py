import datetime as dt
import unittest
import roster_runner as r

class SafetyTests(unittest.TestCase):
    def test_demo_never_bet_ready(self):
        now, game, players, source = r.sample_games()
        kickoff=dt.datetime.fromisoformat(game['kickoff'].replace('Z','+00:00'))
        stats=r.merge_provider_status(players,source,now,kickoff)
        gates=r.report_game(game,players,stats,now,True)
        self.assertTrue(all(g['market_ready'] is False for g in gates))
        self.assertEqual(sum(p['availability']=='CONFIRMED_PROVIDER_INACTIVE' for p in players),2)
        self.assertEqual(len(gates),2)
    def test_names_are_not_sufficient_for_certification(self):
        now, game, players, source=r.sample_games()
        kickoff=dt.datetime.fromisoformat(game['kickoff'].replace('Z','+00:00'))
        source['home']['players'][0]['name']='Different QB'
        stats=r.merge_provider_status(players,source,now,kickoff)
        self.assertIn('Different QB',stats['EXH']['unmatched'])
        self.assertFalse(stats['EXH']['potentially_complete'])
    def test_no_post_kickoff_game_identity(self):
        now,game,players,src=r.sample_games()
        kickoff=dt.datetime.fromisoformat(game['kickoff'].replace('Z','+00:00'))
        provider={'home':{'alias':game['home']},'away':{'alias':game['away']},'scheduled':game['kickoff'],
                  'status':'inprogress','id':'abc'}
        with self.assertRaises(ValueError):r.parse_provider_game(provider,game['home'],game['away'],kickoff)
    def test_absent_provider_keeps_unknown(self):
        now,game,players,source=r.sample_games()
        kickoff=dt.datetime.fromisoformat(game['kickoff'].replace('Z','+00:00'))
        self.assertEqual(r.merge_provider_status(players,None,now,kickoff),{})
        self.assertTrue(all(x['availability']=='UNKNOWN_NOT_VERIFIED' for x in players))

if __name__=='__main__':unittest.main()
